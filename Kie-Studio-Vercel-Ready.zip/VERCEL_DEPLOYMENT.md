# Kie Studio — Vercel Deployment

## Deployment layout
- Vite builds the frontend into `public/`, which Vercel serves as static assets.
- The root `server.ts` exports the Express application. Vercel runs it as a Node.js Function.
- Existing API paths remain under `/api`.

## GitHub → Vercel
1. Extract this ZIP.
2. Create a new GitHub repository and upload the project contents (the files inside the ZIP, not the ZIP itself).
3. In Vercel, choose **Add New → Project**, import the repository, and deploy.
4. Keep the project root at `/` (repository root).
5. Build command: `npm run build`.
6. Output directory: `public`.
7. Install command: `npm install`.
8. Node.js runtime: 22.x or newer.

The included `vercel.json` already specifies the build command, output directory, and a 300-second Function duration.

## Environment variables
The app's Kie.ai API key is supplied by the user through the app's key manager and sent to the backend in the `X-Kie-Api-Key` request header. Do not put a personal Kie.ai API key in frontend code or commit it to GitHub.

If you use the app's server-side encrypted key/session features, add these in Vercel → Project → Settings → Environment Variables:
- `KEY_ENCRYPTION_SECRET`: a strong private secret (use a long random value; never expose it in frontend variables).
- `SESSION_SECRET`: a separate strong private secret if session signing is used.
- `APP_URL`: your deployed `https://<project-name>.vercel.app` URL only if the app's integration flow requires it.

Do not add `GEMINI_API_KEY` unless you separately use a Gemini feature that requires it. The app's current Kie.ai key flow is user-provided.

## Important limitations to test
1. Vercel Function request and response bodies are limited to 4.5 MB. The current app has upload routes that accept larger media in a conventional Node server; large uploads sent through Vercel may fail with HTTP 413. For reliable large video/image uploads, change the upload flow to send files directly to Kie.ai or an external object-storage provider using a secure upload URL.
2. `.data/kie-studio-catalog.db` is local SQLite cache storage. Vercel's function filesystem is not persistent across deployments/instances. The catalog cache can be recreated, but it must not be treated as durable user data.
3. Run a full smoke test after deployment: `/api/health`, catalog loading, key verification, image generation, video generation, task polling, downloads, chat streaming, and both small and large file uploads.
4. Never commit `.env.local`, `.env`, API keys, or generated secrets.

## Local test
```bash
npm install
npm run build
npm run dev
```

For Vercel-like local behavior, install the Vercel CLI and run:
```bash
npx vercel dev
```
