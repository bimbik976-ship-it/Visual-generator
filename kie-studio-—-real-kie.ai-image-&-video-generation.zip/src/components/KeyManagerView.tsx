import React, { useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  KeyRound,
  Loader2,
  Plus,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Star,
  Trash2,
  XCircle,
} from 'lucide-react';
import { api } from '../api';
import {
  MAX_LOCAL_KEYS,
  addLocalKeyEntry,
  removeLocalKeyEntry,
  replaceLocalKeyEntry,
  setActiveLocalKey,
  updateLocalKeyVerification,
} from '../storage/localVault';
import type { KeyStatus, LocalApiKey } from '../types';

interface KeyManagerViewProps {
  deviceId: string;
  keys: LocalApiKey[];
  autoRotateEnabled: boolean;
  onKeysChange: (keys: LocalApiKey[]) => void;
  onToggleAutoRotate: (enabled: boolean) => void;
  onClearAllLocalData: () => void;
}

function renderKeyStatus(status: KeyStatus) {
  switch (status) {
    case 'Valid':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700">
          <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
          <span>Valid</span>
        </span>
      );
    case 'Insufficient Balance':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700">
          <AlertCircle className="h-3.5 w-3.5 shrink-0" />
          <span>Insufficient Balance</span>
        </span>
      );
    case 'Invalid':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-red-700">
          <XCircle className="h-3.5 w-3.5 shrink-0" />
          <span>Invalid</span>
        </span>
      );
    case 'Restricted':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-red-700">
          <ShieldAlert className="h-3.5 w-3.5 shrink-0" />
          <span>Restricted</span>
        </span>
      );
    case 'Rate Limited':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700">
          <AlertCircle className="h-3.5 w-3.5 shrink-0" />
          <span>Rate Limited</span>
        </span>
      );
    case 'Balance Unavailable':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600">
          <AlertCircle className="h-3.5 w-3.5 shrink-0" />
          <span>Balance Unavailable</span>
        </span>
      );
    default:
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500">
          <AlertCircle className="h-3.5 w-3.5 shrink-0" />
          <span>Unknown</span>
        </span>
      );
  }
}

export function KeyManagerView({
  deviceId,
  keys,
  autoRotateEnabled,
  onKeysChange,
  onToggleAutoRotate,
  onClearAllLocalData,
}: KeyManagerViewProps) {
  const [label, setLabel] = useState('');
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [adding, setAdding] = useState(false);
  const [verifyingAll, setVerifyingAll] = useState(false);
  const [busyKeyId, setBusyKeyId] = useState<string | null>(null);
  const [replacingKeyId, setReplacingKeyId] = useState<string | null>(null);
  const [replaceLabel, setReplaceLabel] = useState('');
  const [replaceSecret, setReplaceSecret] = useState('');
  const [confirmClearData, setConfirmClearData] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'error' | 'info'; message: string } | null>(
    null
  );

  const totalBalance = keys.reduce(
    (sum, k) => (typeof k.balance === 'number' ? sum + k.balance : sum),
    0
  );
  const validCount = keys.filter((k) => k.status === 'Valid').length;

  async function handleAddKey(e: React.FormEvent) {
    e.preventDefault();
    setFeedback(null);
    const trimmed = apiKeyInput.trim();
    if (!trimmed) return;
    setAdding(true);
    try {
      const verify = await api.verifyKey(trimmed);
      const next = addLocalKeyEntry(keys, label, trimmed, {
        status: verify.status,
        balance: verify.balance,
        error: verify.error,
        checkedAt: verify.checkedAt,
      });
      setLabel('');
      setApiKeyInput('');
      onKeysChange(next);
      setFeedback({
        type: verify.ok ? 'info' : 'error',
        message: verify.ok
          ? `Key saved locally and verified (${verify.balance} credits).`
          : `Key saved with status "${verify.status}": ${verify.error || 'Verification failed.'}`,
      });
    } catch (err) {
      setFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Failed to add API key.',
      });
    } finally {
      setAdding(false);
    }
  }

  async function handleVerifyOne(key: LocalApiKey) {
    setFeedback(null);
    setBusyKeyId(key.id);
    try {
      const res = await api.verifyKey(key.apiKey);
      const next = updateLocalKeyVerification(keys, key.id, {
        status: res.status,
        balance: res.balance,
        lastError: res.error ?? null,
        checkedAt: res.checkedAt,
      });
      onKeysChange(next);
    } catch (err) {
      setFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Balance check failed.',
      });
    } finally {
      setBusyKeyId(null);
    }
  }

  async function handleVerifyAll() {
    if (keys.length === 0) return;
    setFeedback(null);
    setVerifyingAll(true);
    try {
      let current = [...keys];
      for (const k of keys) {
        const res = await api.verifyKey(k.apiKey).catch((err) => ({
          ok: false,
          status: 'Balance Unavailable' as KeyStatus,
          balance: null,
          error: err instanceof Error ? err.message : 'Network error',
          checkedAt: Date.now(),
        }));
        current = updateLocalKeyVerification(current, k.id, {
          status: res.status,
          balance: res.balance,
          lastError: res.error ?? null,
          checkedAt: res.checkedAt,
        });
      }
      onKeysChange(current);
      setFeedback({
        type: 'info',
        message: `Refreshed live balances for ${keys.length} local key${keys.length === 1 ? '' : 's'}.`,
      });
    } finally {
      setVerifyingAll(false);
    }
  }

  function handleSetActive(id: string) {
    setFeedback(null);
    const next = setActiveLocalKey(keys, id);
    onKeysChange(next);
  }

  function handleRemove(id: string) {
    setFeedback(null);
    const next = removeLocalKeyEntry(keys, id);
    onKeysChange(next);
  }

  async function handleReplaceSubmit(e: React.FormEvent, id: string) {
    e.preventDefault();
    setFeedback(null);
    const trimmed = replaceSecret.trim();
    if (!trimmed) return;
    setBusyKeyId(id);
    try {
      const verify = await api.verifyKey(trimmed);
      const next = replaceLocalKeyEntry(keys, id, replaceLabel, trimmed, {
        status: verify.status,
        balance: verify.balance,
        error: verify.error,
        checkedAt: verify.checkedAt,
      });
      setReplaceSecret('');
      setReplaceLabel('');
      setReplacingKeyId(null);
      onKeysChange(next);
      setFeedback({
        type: verify.ok ? 'info' : 'error',
        message: verify.ok
          ? `Replacement key verified (${verify.balance} credits).`
          : `Replacement key saved with status "${verify.status}": ${verify.error || ''}`,
      });
    } catch (err) {
      setFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Failed to replace API key.',
      });
    } finally {
      setBusyKeyId(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900">
            API Key Manager
          </h1>
          <p className="mt-1.5 text-sm text-slate-600">
            Manage up to 10 Kie.ai API keys on this browser installation. No login or account required.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleVerifyAll}
            disabled={verifyingAll || keys.length === 0}
            className="inline-flex items-center gap-2 rounded-md border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-800 transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${verifyingAll ? 'animate-spin' : ''}`} />
            <span>Refresh All Balances</span>
          </button>

          {!confirmClearData ? (
            <button
              type="button"
              onClick={() => setConfirmClearData(true)}
              className="inline-flex items-center gap-2 rounded-md border border-red-200 bg-white px-4 py-2 text-xs font-medium text-red-700 transition-colors hover:bg-red-50 whitespace-nowrap shrink-0"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span>Clear Local Data</span>
            </button>
          ) : (
            <div className="inline-flex items-center gap-2 rounded-md border border-red-300 bg-red-50 px-3 py-1.5">
              <span className="text-xs font-medium text-red-800">
                Wipe all local keys &amp; histories?
              </span>
              <button
                type="button"
                onClick={() => {
                  onClearAllLocalData();
                  setConfirmClearData(false);
                  setFeedback({
                    type: 'info',
                    message: 'All local keys, preferences, and histories cleared from this device.',
                  });
                }}
                className="rounded bg-red-700 px-2.5 py-1 text-xs font-medium text-white hover:bg-red-800 whitespace-nowrap"
              >
                Confirm Wipe
              </button>
              <button
                type="button"
                onClick={() => setConfirmClearData(false)}
                className="rounded border border-slate-300 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Summary Metrics Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">Local Key Slots</div>
          <div className="mt-2 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
            {keys.length} / {MAX_LOCAL_KEYS}
          </div>
          <div className="mt-1 text-xs text-slate-500">Stored locally on this device</div>
        </div>
        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">Valid Keys</div>
          <div className="mt-2 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
            {validCount}
          </div>
          <div className="mt-1 text-xs text-slate-500">Verified balance &gt; 0 credits</div>
        </div>
        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">Combined Balance</div>
          <div className="mt-2 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
            {totalBalance.toLocaleString(undefined, { maximumFractionDigits: 4 })} cr
          </div>
          <div className="mt-1 text-xs text-slate-500">Across saved keys</div>
        </div>
        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Automatic Rotation</span>
            <input
              id="toggle-auto-rotate"
              type="checkbox"
              checked={autoRotateEnabled}
              onChange={(e) => onToggleAutoRotate(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-slate-900 focus:ring-blue-600"
            />
          </div>
          <label
            htmlFor="toggle-auto-rotate"
            className="mt-2 block cursor-pointer font-mono text-base font-semibold text-slate-900"
          >
            {autoRotateEnabled ? 'Enabled' : 'Disabled'}
          </label>
          <div className="mt-1 text-xs text-slate-500">
            Rotates only on insufficient credits
          </div>
        </div>
      </div>

      {feedback && (
        <div
          className={`flex items-start gap-2.5 rounded-md border px-4 py-3 text-sm ${
            feedback.type === 'error'
              ? 'border-red-200 bg-red-50 text-red-700'
              : 'border-slate-200 bg-white text-slate-800'
          }`}
        >
          {feedback.type === 'error' ? (
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          ) : (
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
          )}
          <span>{feedback.message}</span>
        </div>
      )}

      {/* Add Key Form */}
      <form onSubmit={handleAddKey} className="rounded-lg border border-slate-200 bg-white p-6">
        <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
          <KeyRound className="h-4 w-4 text-slate-700" />
          <span>Add Kie.ai API Key</span>
        </div>
        <p className="mt-1 text-xs text-slate-600">
          Keys are checked live against <span className="font-mono">GET /api/v1/chat/credit</span> through our stateless proxy before saving locally.
        </p>

        <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-12">
          <div className="md:col-span-4">
            <label htmlFor="key-label" className="block text-xs font-medium text-slate-700">
              Key Label
            </label>
            <input
              id="key-label"
              type="text"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder={`API KEY ${String(keys.length + 1).padStart(2, '0')} — Main`}
              maxLength={48}
              className="mt-1.5 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none"
            />
          </div>
          <div className="md:col-span-6">
            <label htmlFor="key-secret" className="block text-xs font-medium text-slate-700">
              Kie.ai Bearer API Key
            </label>
            <input
              id="key-secret"
              type="password"
              required
              autoComplete="off"
              value={apiKeyInput}
              onChange={(e) => setApiKeyInput(e.target.value)}
              placeholder="Paste your Kie.ai API key"
              className="mt-1.5 w-full rounded-md border border-slate-300 bg-white px-3 py-2 font-mono text-sm text-slate-900 placeholder:font-sans placeholder:text-slate-400 focus:border-blue-600 focus:outline-none"
            />
          </div>
          <div className="flex items-end md:col-span-2">
            <button
              type="submit"
              disabled={adding || keys.length >= MAX_LOCAL_KEYS || !apiKeyInput.trim()}
              className="flex w-full items-center justify-center gap-2 rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap"
            >
              {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              <span>Add Key</span>
            </button>
          </div>
        </div>
      </form>

      {/* Keys Table */}
      <div className="overflow-hidden rounded-lg border border-slate-200 bg-white">
        {keys.length === 0 ? (
          <div className="p-10 text-center">
            <p className="text-sm font-medium text-slate-900">No API keys configured on this device</p>
            <p className="mt-1 text-xs text-slate-600">
              Add your Kie.ai API key above to verify your live balance and unlock Video, Image, and Chat generation.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-600">
                  <th className="px-4 py-3">Label</th>
                  <th className="px-4 py-3">Masked Identifier</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 text-right">Verified Balance</th>
                  <th className="px-4 py-3">Last Checked</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {keys.map((k) => (
                  <React.Fragment key={k.id}>
                    <tr className="hover:bg-slate-50/60">
                      <td className="px-4 py-3.5 align-top">
                        <div className="font-medium text-slate-900">
                          {k.label}
                          {k.isActive && (
                            <span className="ml-2 text-xs font-medium text-blue-700">
                              · Active
                            </span>
                          )}
                        </div>
                        {k.lastError && (
                          <div className="mt-1 max-w-xs text-xs text-red-600">{k.lastError}</div>
                        )}
                      </td>
                      <td className="px-4 py-3.5 align-top font-mono text-xs text-slate-700">
                        {k.maskedKey}
                      </td>
                      <td className="px-4 py-3.5 align-top whitespace-nowrap">
                        {renderKeyStatus(k.status)}
                      </td>
                      <td className="px-4 py-3.5 align-top text-right font-mono text-sm font-medium text-slate-900 tabular-nums">
                        {k.balance !== null
                          ? `${k.balance.toLocaleString(undefined, { maximumFractionDigits: 4 })} cr`
                          : '—'}
                      </td>
                      <td className="px-4 py-3.5 align-top text-xs text-slate-500 tabular-nums">
                        {k.lastCheckedAt ? new Date(k.lastCheckedAt).toLocaleString() : 'Never'}
                      </td>
                      <td className="px-4 py-3.5 align-top text-right">
                        <div className="inline-flex items-center justify-end gap-2">
                          {!k.isActive && (
                            <button
                              type="button"
                              onClick={() => handleSetActive(k.id)}
                              disabled={busyKeyId === k.id}
                              className="inline-flex items-center gap-1 rounded border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap"
                            >
                              <Star className="h-3 w-3" />
                              <span>Set Active</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleVerifyOne(k)}
                            disabled={busyKeyId === k.id}
                            className="inline-flex items-center gap-1 rounded border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap"
                          >
                            <RefreshCw
                              className={`h-3 w-3 ${busyKeyId === k.id ? 'animate-spin' : ''}`}
                            />
                            <span>Validate</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (replacingKeyId === k.id) {
                                setReplacingKeyId(null);
                                setReplaceSecret('');
                              } else {
                                setReplacingKeyId(k.id);
                                setReplaceLabel(k.label);
                                setReplaceSecret('');
                              }
                            }}
                            className="rounded border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap"
                          >
                            Replace
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRemove(k.id)}
                            disabled={busyKeyId === k.id}
                            aria-label={`Remove ${k.label}`}
                            className="rounded border border-red-200 p-1.5 text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                    {replacingKeyId === k.id && (
                      <tr className="bg-slate-50">
                        <td colSpan={6} className="px-4 py-4">
                          <form
                            onSubmit={(e) => handleReplaceSubmit(e, k.id)}
                            className="flex flex-wrap items-end gap-3"
                          >
                            <div className="min-w-[180px] flex-1">
                              <label className="block text-xs font-medium text-slate-700">
                                Updated Label
                              </label>
                              <input
                                type="text"
                                value={replaceLabel}
                                onChange={(e) => setReplaceLabel(e.target.value)}
                                className="mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-1.5 text-sm"
                              />
                            </div>
                            <div className="min-w-[260px] flex-[2]">
                              <label className="block text-xs font-medium text-slate-700">
                                Replacement Kie.ai API Key
                              </label>
                              <input
                                type="password"
                                required
                                autoComplete="off"
                                value={replaceSecret}
                                onChange={(e) => setReplaceSecret(e.target.value)}
                                placeholder="Paste replacement API key"
                                className="mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-1.5 font-mono text-sm"
                              />
                            </div>
                            <button
                              type="submit"
                              disabled={busyKeyId === k.id || !replaceSecret.trim()}
                              className="rounded-md bg-slate-900 px-4 py-1.5 text-xs font-medium text-white hover:bg-slate-800 whitespace-nowrap"
                            >
                              Save Replacement
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setReplacingKeyId(null);
                                setReplaceSecret('');
                              }}
                              className="rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap"
                            >
                              Cancel
                            </button>
                          </form>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Local Storage Security Notice & Rotation Policy */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="rounded-lg border border-slate-200 bg-white p-5 text-xs leading-relaxed text-slate-600">
          <div className="flex items-center gap-2 font-semibold text-slate-900">
            <ShieldCheck className="h-4 w-4 text-slate-700" />
            <span>Local Device Storage &amp; Security Notice</span>
          </div>
          <p className="mt-2">
            Because login and user accounts are removed, your API keys, preferences, and generation histories are stored locally in this browser&apos;s <span className="font-mono">localStorage</span> under installation profile <span className="font-mono">{deviceId.slice(0, 8)}…</span>.
          </p>
          <ul className="mt-2 list-disc space-y-1 pl-4">
            <li>Keys never sync across devices or different browsers and are never persisted or logged on the server.</li>
            <li>Requests pass through our stateless server proxy over HTTPS/local origin using <span className="font-mono">X-Kie-Api-Key</span>.</li>
            <li>Browser <span className="font-mono">localStorage</span> is readable by JavaScript or extensions running on the same origin. Use <strong>Clear Local Data</strong> on shared machines.</li>
          </ul>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-5 text-xs leading-relaxed text-slate-600">
          <div className="font-semibold text-slate-900">Automatic Key Rotation Policy</div>
          <p className="mt-2">
            When Automatic Rotation is enabled and your active or selected key has insufficient credits for a verified generation cost (or returns 402 Insufficient Balance), the app verifies remaining local keys in priority order against <span className="font-mono">GET /api/v1/chat/credit</span> and submits using the first key with enough verified credits.
          </p>
          <p className="mt-2">
            Rotation <strong>never</strong> triggers on invalid parameters, unavailable models, invalid/restricted keys, or API server errors.
          </p>
        </div>
      </div>
    </div>
  );
}
