import { getOrCreateDeviceId } from './storage/localVault';
import type {
  AffordabilitySummary,
  CatalogModel,
  ChatAttachmentPayload,
  ChatTokenUsage,
  CostCalculationResult,
  GenerationStatus,
  KeyStatus,
  ModelCategory,
} from './types';

export interface ZipParseResponse {
  ok: boolean;
  fileName: string;
  archiveSize: number;
  totalEntries: number;
  entries: Array<{
    path: string;
    size: number;
    kind: 'text' | 'image' | 'video' | 'executable' | 'binary' | 'unsafe';
    status: 'parsed' | 'truncated' | 'skipped' | 'error';
    reason?: string;
  }>;
  textFiles: Array<{
    path: string;
    size: number;
    content: string;
    truncated: boolean;
  }>;
  images: Array<{
    path: string;
    mimeType: string;
    size: number;
    dataUrl: string;
  }>;
  summaryText: string;
  warnings: string[];
  error?: string;
}

async function requestJson<T>(url: string, options?: RequestInit): Promise<T> {
  const { headers: extraHeaders, ...restOptions } = options || {};
  const res = await fetch(url, {
    ...restOptions,
    headers: {
      'Content-Type': 'application/json',
      'X-Device-Id': getOrCreateDeviceId(),
      ...(extraHeaders || {}),
    },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg =
      (data as { error?: string; msg?: string }).error ||
      (data as { msg?: string }).msg ||
      `Request failed (HTTP ${res.status})`;
    throw new Error(msg);
  }
  return data as T;
}

export const api = {
  // Public Live Catalog & Pricing
  getCatalog: () =>
    requestJson<{
      syncedAt: number | null;
      syncing: boolean;
      stale: boolean;
      lastError: string | null;
      docsWarning?: string | null;
      models: CatalogModel[];
    }>('/api/catalog'),

  syncCatalog: (force = false) =>
    requestJson<{
      ok: boolean;
      syncedAt: number | null;
      syncing: boolean;
      stale: boolean;
      lastError: string | null;
      docsWarning?: string | null;
      models: CatalogModel[];
    }>('/api/catalog/sync', {
      method: 'POST',
      body: JSON.stringify({ force }),
    }),

  getModelDetail: (id: string, category?: ModelCategory) =>
    requestJson<{ model: CatalogModel }>(
      `/api/catalog/model?id=${encodeURIComponent(id)}${category ? `&category=${encodeURIComponent(category)}` : ''}`
    ),

  calculatePricing: (
    modelId: string,
    category: ModelCategory,
    input: Record<string, unknown>,
    balance: number | null
  ) =>
    requestJson<{ cost: CostCalculationResult; affordability: AffordabilitySummary }>(
      '/api/pricing/calculate',
      {
        method: 'POST',
        body: JSON.stringify({ modelId, category, input, balance }),
      }
    ),

  // Stateless Proxy: Key Balance Verification
  verifyKey: async (
    apiKey: string
  ): Promise<{
    ok: boolean;
    status: KeyStatus;
    balance: number | null;
    error?: string;
    checkedAt: number;
  }> => {
    return requestJson('/api/proxy/verify-key', {
      method: 'POST',
      headers: {
        'X-Kie-Api-Key': apiKey.trim(),
      },
    });
  },

  // Stateless Proxy: File Upload (Base64 for <=10MB, Stream for >10MB per Kie.ai docs)
  uploadFile: (
    apiKey: string,
    base64Data: string,
    fileName: string,
    options?: {
      allowedMimeTypes?: string[];
      maxBytes?: number;
      uploadPath?: string;
    }
  ) =>
    requestJson<{
      ok: boolean;
      fileUrl: string;
      fileName?: string;
      mimeType?: string;
      size?: number;
    }>('/api/proxy/upload', {
      method: 'POST',
      headers: {
        'X-Kie-Api-Key': apiKey.trim(),
      },
      body: JSON.stringify({
        base64Data,
        fileName,
        allowedMimeTypes: options?.allowedMimeTypes,
        maxBytes: options?.maxBytes,
        uploadPath: options?.uploadPath,
      }),
    }),

  uploadMediaStreamFile: async (
    apiKey: string,
    file: File,
    options?: {
      allowedMimeTypes?: string[];
      maxBytes?: number;
      uploadPath?: string;
    }
  ): Promise<{
    ok: boolean;
    fileUrl: string;
    fileName?: string;
    mimeType?: string;
    size?: number;
  }> => {
    const safeName = file.name.replace(/[^\w.\-() ]+/g, '_') || 'upload.bin';
    const res = await fetch('/api/proxy/media/upload-stream', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/octet-stream',
        'X-Device-Id': getOrCreateDeviceId(),
        'X-Kie-Api-Key': apiKey.trim(),
        'X-File-Name': safeName,
        ...(options?.allowedMimeTypes?.length
          ? { 'X-Allowed-Mimes': options.allowedMimeTypes.join(',') }
          : {}),
        ...(options?.maxBytes ? { 'X-Max-Bytes': String(options.maxBytes) } : {}),
        ...(options?.uploadPath ? { 'X-Upload-Path': options.uploadPath } : {}),
      },
      body: file,
    });
    const data = (await res.json().catch(() => ({}))) as {
      ok?: boolean;
      fileUrl?: string;
      fileName?: string;
      mimeType?: string;
      size?: number;
      error?: string;
    };
    if (!res.ok || !data.fileUrl) {
      throw new Error(data.error || `Stream file upload failed (HTTP ${res.status})`);
    }
    return {
      ok: true,
      fileUrl: data.fileUrl,
      fileName: data.fileName || safeName,
      mimeType: data.mimeType || file.type,
      size: data.size || file.size,
    };
  },

  // Stateless Proxy: Submit Video / Image Generation
  submitMediaGeneration: async (
    apiKey: string,
    payload: {
      clientRequestId: string;
      modelId: string;
      category: 'video' | 'image';
      generationMode: string;
      input: Record<string, unknown>;
    }
  ): Promise<{
    ok: boolean;
    httpStatus: number;
    duplicate?: boolean;
    ambiguousTimeout?: boolean;
    taskId?: string;
    rawState?: string;
    status?: GenerationStatus;
    verifiedCost?: number;
    verifiedBalance?: number;
    endpointPath?: string;
    sanitizedInput?: Record<string, unknown>;
    insufficientCredits?: boolean;
    invalidKey?: boolean;
    restricted?: boolean;
    rateLimited?: boolean;
    keyStatus?: KeyStatus;
    errorCode?: string;
    error?: string;
  }> => {
    const res = await fetch('/api/proxy/media/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Device-Id': getOrCreateDeviceId(),
        'X-Kie-Api-Key': apiKey.trim(),
      },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    return {
      httpStatus: res.status,
      ...(data as Record<string, unknown>),
    } as Awaited<ReturnType<typeof api.submitMediaGeneration>>;
  },

  // Stateless Proxy: Poll Media Task Status
  pollMediaTask: async (
    apiKey: string,
    taskId: string,
    category: 'video' | 'image'
  ): Promise<{
    ok: boolean;
    status?: GenerationStatus;
    rawState?: string | null;
    resultUrls?: string[];
    mediaVerified?: boolean;
    errorCode?: string | null;
    errorMessage?: string | null;
    creditsConsumed?: number | null;
    updatedBalance?: number | null;
    error?: string;
  }> => {
    const res = await fetch('/api/proxy/media/poll', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Device-Id': getOrCreateDeviceId(),
        'X-Kie-Api-Key': apiKey.trim(),
      },
      body: JSON.stringify({ taskId, category }),
    });
    const data = await res.json().catch(() => ({}));
    return data as Awaited<ReturnType<typeof api.pollMediaTask>>;
  },

  // Stateless Proxy: Download Verified Media (never puts key in URL)
  downloadMediaBlob: async (
    apiKey: string | undefined,
    url: string,
    filename: string
  ): Promise<void> => {
    const res = await fetch('/api/proxy/media/download', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Device-Id': getOrCreateDeviceId(),
        ...(apiKey ? { 'X-Kie-Api-Key': apiKey.trim() } : {}),
      },
      body: JSON.stringify({ url, filename }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error((err as { error?: string }).error || `Download failed (HTTP ${res.status})`);
    }
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = objectUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 5000);
  },

  // Stateless Proxy: Parse ZIP Archive securely on server
  parseChatZip: async (file: File): Promise<ZipParseResponse> => {
    const safeName = file.name.replace(/[^\w.\-() ]+/g, '_') || 'archive.zip';
    const res = await fetch('/api/proxy/chat/parse-zip', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/octet-stream',
        'X-Device-Id': getOrCreateDeviceId(),
        'X-File-Name': safeName,
      },
      body: file,
    });
    const data = (await res.json().catch(() => ({}))) as Partial<ZipParseResponse>;
    if (!res.ok || !data.ok) {
      throw new Error(data.error || `Failed to inspect ZIP archive (HTTP ${res.status})`);
    }
    return data as ZipParseResponse;
  },

  // Stateless Proxy: Upload Chat Image or Video directly to Kie.ai stream upload
  uploadChatMediaFile: async (
    apiKey: string,
    file: File
  ): Promise<{ fileUrl: string; mimeType: string; size: number; fileName: string }> => {
    const safeName = file.name.replace(/[^\w.\-() ]+/g, '_') || 'upload.bin';
    const res = await fetch('/api/proxy/chat/upload', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/octet-stream',
        'X-Device-Id': getOrCreateDeviceId(),
        'X-Kie-Api-Key': apiKey.trim(),
        'X-File-Name': safeName,
      },
      body: file,
    });
    const data = (await res.json().catch(() => ({}))) as {
      ok?: boolean;
      fileUrl?: string;
      mimeType?: string;
      size?: number;
      fileName?: string;
      error?: string;
    };
    if (!res.ok || !data.ok || !data.fileUrl) {
      throw new Error(data.error || `File upload failed (HTTP ${res.status})`);
    }
    return {
      fileUrl: data.fileUrl,
      mimeType: data.mimeType || file.type,
      size: data.size || file.size,
      fileName: data.fileName || safeName,
    };
  },

  // Stateless Proxy: Chat Send (SSE streaming + non-streaming JSON models + pre-stream balance check)
  sendChatStream: async (params: {
    apiKey: string;
    clientRequestId: string;
    modelId: string;
    messages: Array<{
      role: 'user' | 'assistant';
      content: string;
      attachments?: ChatAttachmentPayload[];
    }>;
    systemPrompt?: string;
    temperature?: number;
    maxTokens?: number;
    signal?: AbortSignal;
    onDelta: (text: string) => void;
    onProcessing?: (message: string) => void;
  }): Promise<{
    ok: boolean;
    text: string;
    providerModel?: string;
    usage?: ChatTokenUsage | null;
    updatedBalance?: number | null;
    updatedKeyStatus?: KeyStatus;
    insufficientCredits?: boolean;
    invalidKey?: boolean;
    restricted?: boolean;
    rateLimited?: boolean;
    verifiedBalance?: number | null;
    keyStatus?: KeyStatus;
    error?: string;
  }> => {
    const res = await fetch('/api/proxy/chat/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Device-Id': getOrCreateDeviceId(),
        'X-Kie-Api-Key': params.apiKey.trim(),
      },
      body: JSON.stringify({
        clientRequestId: params.clientRequestId,
        modelId: params.modelId,
        messages: params.messages,
        systemPrompt: params.systemPrompt,
        temperature: params.temperature,
        maxTokens: params.maxTokens,
      }),
      signal: params.signal,
    });

    const contentType = res.headers.get('content-type') || '';
    if (!res.ok || !contentType.includes('text/event-stream')) {
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
        insufficientCredits?: boolean;
        invalidKey?: boolean;
        restricted?: boolean;
        rateLimited?: boolean;
        verifiedBalance?: number | null;
        keyStatus?: KeyStatus;
      };
      return {
        ok: false,
        text: '',
        insufficientCredits: json.insufficientCredits,
        invalidKey: json.invalidKey,
        restricted: json.restricted,
        rateLimited: json.rateLimited,
        verifiedBalance: json.verifiedBalance,
        keyStatus: json.keyStatus,
        error: json.error || `Chat request failed (HTTP ${res.status})`,
      };
    }

    if (!res.body) {
      return { ok: false, text: '', error: 'Empty SSE response stream.' };
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let currentEvent = 'message';
    let fullText = '';
    interface DonePayload {
      text?: string;
      providerModel?: string;
      usage?: ChatTokenUsage | null;
      updatedBalance?: number | null;
      updatedKeyStatus?: KeyStatus;
    }
    interface StreamErrorPayload {
      error?: string;
      insufficientCredits?: boolean;
      invalidKey?: boolean;
      restricted?: boolean;
      rateLimited?: boolean;
    }
    let donePayload: DonePayload | null = null;
    let streamError: StreamErrorPayload | null = null;

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() ?? '';

      for (const rawLine of lines) {
        const line = rawLine.trim();
        if (!line) {
          currentEvent = 'message';
          continue;
        }
        if (line.startsWith('event:')) {
          currentEvent = line.slice(6).trim();
          continue;
        }
        if (line.startsWith('data:')) {
          const payloadStr = line.slice(5).trim();
          if (!payloadStr) continue;
          try {
            const data = JSON.parse(payloadStr) as Record<string, unknown>;
            if (currentEvent === 'delta' && typeof data.text === 'string') {
              fullText += data.text;
              params.onDelta(fullText);
            } else if (currentEvent === 'processing' && typeof data.message === 'string') {
              params.onProcessing?.(data.message);
            } else if (currentEvent === 'done') {
              donePayload = data as unknown as DonePayload;
            } else if (currentEvent === 'error') {
              streamError = data as unknown as StreamErrorPayload;
            }
          } catch {
            // ignore partial JSON chunks
          }
        }
      }
    }

    if (streamError) {
      return {
        ok: false,
        text: fullText,
        insufficientCredits: streamError.insufficientCredits,
        invalidKey: streamError.invalidKey,
        restricted: streamError.restricted,
        rateLimited: streamError.rateLimited,
        error: streamError.error || 'Chat stream failed.',
      };
    }

    if (donePayload) {
      return {
        ok: true,
        text: donePayload.text || fullText,
        providerModel: donePayload.providerModel,
        usage: donePayload.usage ?? null,
        updatedBalance: donePayload.updatedBalance ?? null,
        updatedKeyStatus: donePayload.updatedKeyStatus,
      };
    }

    return {
      ok: Boolean(fullText),
      text: fullText,
      error: fullText ? undefined : 'Chat stream ended unexpectedly without completion.',
    };
  },
};
