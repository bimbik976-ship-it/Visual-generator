import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { api } from './api';
import { ChatGeneratorView } from './components/ChatGeneratorView';
import { KeyManagerView } from './components/KeyManagerView';
import { MediaGeneratorView } from './components/MediaGeneratorView';
import {
  clearAllLocalData,
  getOrCreateDeviceId,
  loadChatConversations,
  loadLocalKeys,
  loadMediaHistory,
  loadPreferences,
  saveChatConversations,
  saveLocalKeys,
  saveMediaHistory,
  savePreferences,
  updateLocalKeyVerification,
} from './storage/localVault';
import type {
  CatalogModel,
  ChatConversation,
  KeyStatus,
  LocalApiKey,
  LocalMediaTask,
} from './types';

type ActiveMenu = 'video' | 'image' | 'chat' | 'keys';

export default function App() {
  const [activeMenu, setActiveMenu] = useState<ActiveMenu>('video');
  const [deviceId] = useState<string>(() => getOrCreateDeviceId());

  const [models, setModels] = useState<CatalogModel[]>([]);
  const [syncedAt, setSyncedAt] = useState<number | null>(null);
  const [catalogSyncing, setCatalogSyncing] = useState(false);
  const [catalogStale, setCatalogStale] = useState(false);
  const [catalogError, setCatalogError] = useState<string | null>(null);

  const [keys, setKeys] = useState<LocalApiKey[]>(() => loadLocalKeys());
  const [autoRotateEnabled, setAutoRotateEnabled] = useState<boolean>(
    () => loadPreferences().autoRotateEnabled
  );
  const [videoTasks, setVideoTasks] = useState<LocalMediaTask[]>(() =>
    loadMediaHistory('video')
  );
  const [imageTasks, setImageTasks] = useState<LocalMediaTask[]>(() =>
    loadMediaHistory('image')
  );
  const [chatConversations, setChatConversations] = useState<ChatConversation[]>(() =>
    loadChatConversations()
  );

  const loadCatalog = useCallback(async () => {
    setCatalogSyncing(true);
    try {
      const cat = await api.getCatalog();
      setModels(cat.models);
      setSyncedAt(cat.syncedAt);
      setCatalogSyncing(cat.syncing);
      setCatalogStale(cat.stale);
      setCatalogError(cat.lastError);
    } catch (err) {
      setCatalogStale(true);
      setCatalogError(err instanceof Error ? err.message : 'Unable to fetch catalog.');
      setCatalogSyncing(false);
    }
  }, []);

  useEffect(() => {
    void loadCatalog();
  }, [loadCatalog]);

  async function handleSyncCatalog() {
    setCatalogSyncing(true);
    setCatalogError(null);
    try {
      const res = await api.syncCatalog(false);
      setModels(res.models);
      setSyncedAt(res.syncedAt);
      setCatalogStale(res.stale);
      setCatalogError(res.lastError);
    } catch (err) {
      setCatalogStale(true);
      setCatalogError(err instanceof Error ? err.message : 'Catalog sync failed.');
    } finally {
      setCatalogSyncing(false);
    }
  }

  function handleKeysChange(nextKeys: LocalApiKey[]) {
    const normalized = saveLocalKeys(nextKeys);
    setKeys(normalized);
  }

  function handleUpdateKeyVerification(
    keyId: string,
    patch: { status: KeyStatus; balance: number | null; lastError?: string | null }
  ) {
    setKeys((prev) => updateLocalKeyVerification(prev, keyId, patch));
  }

  function handleToggleAutoRotate(enabled: boolean) {
    setAutoRotateEnabled(enabled);
    savePreferences({ autoRotateEnabled: enabled });
  }

  function handleVideoTasksChange(next: LocalMediaTask[]) {
    setVideoTasks(next);
    saveMediaHistory('video', next);
  }

  function handleImageTasksChange(next: LocalMediaTask[]) {
    setImageTasks(next);
    saveMediaHistory('image', next);
  }

  function handleChatsChange(next: ChatConversation[]) {
    setChatConversations(next);
    saveChatConversations(next);
  }

  function handleClearAllLocalData() {
    clearAllLocalData();
    setKeys([]);
    setVideoTasks([]);
    setImageTasks([]);
    setChatConversations([]);
    setAutoRotateEnabled(true);
  }

  const activeKey = useMemo(
    () => keys.find((k) => k.isActive) || keys[0] || null,
    [keys]
  );

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-[1400px] items-center justify-between gap-8 px-6 py-3.5">
          {/* Zone 1: Single text element wordmark */}
          <button
            type="button"
            onClick={() => setActiveMenu('video')}
            className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
          >
            Kie Studio
          </button>

          {/* Zone 2: 4 independent main menus */}
          <nav className="flex items-center gap-6 overflow-x-auto text-sm font-medium">
            {(
              [
                { id: 'video', label: 'Video Generator' },
                { id: 'image', label: 'Image Generator' },
                { id: 'chat', label: 'Chat Generator' },
                { id: 'keys', label: 'API Key Manager' },
              ] as const
            ).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveMenu(item.id)}
                className={`border-b-2 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  activeMenu === item.id
                    ? 'border-slate-900 text-slate-900'
                    : 'border-transparent text-slate-500 hover:text-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: Compact Active Key & Balance Summary Action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => setActiveMenu('keys')}
              className={`rounded-md px-3.5 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                activeKey
                  ? 'border border-slate-200 bg-white text-slate-800 hover:bg-slate-50 font-mono tabular-nums'
                  : 'bg-slate-900 text-white hover:bg-slate-800'
              }`}
            >
              {activeKey
                ? `${activeKey.label} · ${
                    activeKey.balance !== null ? `${activeKey.balance} cr` : activeKey.status
                  }`
                : 'Add API Key'}
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1400px] px-6 py-8">
        {activeMenu === 'video' && (
          <MediaGeneratorView
            key="video"
            category="video"
            models={models}
            syncedAt={syncedAt}
            catalogSyncing={catalogSyncing}
            catalogStale={catalogStale}
            catalogError={catalogError}
            onSyncCatalog={handleSyncCatalog}
            keys={keys}
            autoRotateEnabled={autoRotateEnabled}
            onUpdateKeyVerification={handleUpdateKeyVerification}
            tasks={videoTasks}
            onTasksChange={handleVideoTasksChange}
            onGoToKeys={() => setActiveMenu('keys')}
          />
        )}

        {activeMenu === 'image' && (
          <MediaGeneratorView
            key="image"
            category="image"
            models={models}
            syncedAt={syncedAt}
            catalogSyncing={catalogSyncing}
            catalogStale={catalogStale}
            catalogError={catalogError}
            onSyncCatalog={handleSyncCatalog}
            keys={keys}
            autoRotateEnabled={autoRotateEnabled}
            onUpdateKeyVerification={handleUpdateKeyVerification}
            tasks={imageTasks}
            onTasksChange={handleImageTasksChange}
            onGoToKeys={() => setActiveMenu('keys')}
          />
        )}

        {activeMenu === 'chat' && (
          <ChatGeneratorView
            models={models}
            syncedAt={syncedAt}
            catalogSyncing={catalogSyncing}
            catalogStale={catalogStale}
            catalogError={catalogError}
            onSyncCatalog={handleSyncCatalog}
            keys={keys}
            autoRotateEnabled={autoRotateEnabled}
            onUpdateKeyVerification={handleUpdateKeyVerification}
            conversations={chatConversations}
            onConversationsChange={handleChatsChange}
            onGoToKeys={() => setActiveMenu('keys')}
          />
        )}

        {activeMenu === 'keys' && (
          <KeyManagerView
            deviceId={deviceId}
            keys={keys}
            autoRotateEnabled={autoRotateEnabled}
            onKeysChange={handleKeysChange}
            onToggleAutoRotate={handleToggleAutoRotate}
            onClearAllLocalData={handleClearAllLocalData}
          />
        )}
      </main>
    </div>
  );
}
